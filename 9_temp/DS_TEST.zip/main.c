#include <stdio.h>
#include <stdlib.h>
#include "DBLL.h"
#include "MyUI.h"

int main(void)
{
	// 양방향 연결 리스트의 생성 및 초기화  ///////
	List list;
	int data;
	ListInit(&list);
    int i_buf = 0;
    unsigned long Looiter = 0;

	// 8개의 데이터 저장  ///////
    puts("**********************************************");
    puts("Hellow! This program eval DatasStruct");
    puts("********************************************** \r\n");
    puts("init sequence !!");
    UI_Autoinsert(&list);
    puts("\r");

    for(Looiter=0;Looiter<100;Looiter++)
    {
        UI_MainMenu();
        fflush(stdin);
        scanf("%d",&i_buf);

        switch(i_buf)
        {
            case 1 : 
                if(LFirst(&list, &data))
                {
                    UI_ADI_P(&list, &data);
                }
            break;

            case 2 : 
                if(LFirst(&list, &data))
                {
                     UI_ADI_N(&list, &data);
                }
            break;

            case 3 : UI_Autoinsert(&list);
            break;

            case 4 : puts("working...");
            break;
            
            case 5 : puts("working...");
            break;

            case 6 : printf("Current data : %d",data);
            break;

            default : printf("default case number : %d inserted, program terminated!",i_buf);
            i_buf=0;
            break;
        }
        if(i_buf==0)
        {
            break;
        }
        puts("\r\n\r\n ...done!!!");
        fflush(stdin); 
        getchar();


    }
	return 0;
}