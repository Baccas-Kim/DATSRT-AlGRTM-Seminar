#include <stdio.h>
#include "DBLL.h"

int UI_MainMenu(void)
{
    puts("(1) : All data inquire - NEXT Mode");
    puts("(2) : All data inquire - PRE Mode");
    puts("(3) : Insert Data");
    puts("(4) : Delete Data");
    puts("(5) : Auto TEST");
    puts("(6) : Current Data inquire");
    puts("*******************************");
    puts("(0) : Exit Program");
    //puts("*******************************");
    return 1;    
}

int UI_ADI_N(List * plist,Data * pdata)
{
    puts("All data inquire - order down below");
    while(LNext(plist, pdata)) 
    {
		printf("%d ", pdata);
    }	
    return 1;
}

int UI_ADI_P(List * plist,Data * pdata)
{
    puts("All data inquire - reverse order down below");
    while(LPrevious(plist, pdata))
    {
        printf("%d ",pdata);
    }
    return 1;
}

int UI_Autoinsert(List * plist)
{
    puts("Insert 1~8");
    LInsert(plist, 1);  
    LInsert(plist, 2);
	LInsert(plist, 3); 
    LInsert(plist, 4);
	LInsert(plist, 5);  
    LInsert(plist, 6);
	LInsert(plist, 7);  
    LInsert(plist, 8);
}

int UI_2(int argc)
{

}