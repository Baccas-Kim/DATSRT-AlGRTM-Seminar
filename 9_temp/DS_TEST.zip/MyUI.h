#include <stdio.h>
#include "DBLL.h"
List list;

int UI_MainMenu(void);
int UI_ADI_N(List * plist,Data * pdata);
int UI_ADI_P(List * plist,Data * pdata);
int UI_Autoinsert(List * plist);
int UI_2(int argc);
